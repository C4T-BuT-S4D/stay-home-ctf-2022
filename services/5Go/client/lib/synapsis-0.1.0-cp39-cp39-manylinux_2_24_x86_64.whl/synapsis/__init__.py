from .synapsis import *

__doc__ = synapsis.__doc__
